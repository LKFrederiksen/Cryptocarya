# -*- coding: utf-8 -*-

__author__ = 'Marek Borowiec'
__email__ = 'petiolus@gmail.com'
__version__ = '1.02'
__all__ = dir()
