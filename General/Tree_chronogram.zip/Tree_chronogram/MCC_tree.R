#Set your working directory (the folder you've copied all the files into on your machine)
setwd("~/Documents/Uni - Biologi/Speciale/Analyses/Tree_chronogram")

#Install the R package ape - you only need to do this once, not every time you plot a tree
#install.packages("ape")

#Load packages
library(ape)
library(deeptime)
library(ggplot2)
library(dplyr)
library(magrittr) # for piping
library(ggtree)
library(phytools)
library(ggtree)
library(treeio)

### Read in your tree ###
#There are lots of file endings that newick trees can be saved as - to have support values, if you're reading in direct from RAxML-NG, you want the file that ends with .support. If from old RAxML, you want the bipartitions tree. ASTRAL has the .tre ending and the consensus IQTREE tree is .contree

# Read in ASTRAL to get lpp (local posterior probability) scores for the main topology.
astral_tree <- read.astral("Beilschmiedia-Outgroup_trees_BP10_SpeciesTree_annotQ_rooted2.tre")

# See list of lpp scores
list <- astral_tree@data$pp1

# List of lpp scores as a vector
# c("", "", "1", "1", "1", "1", "0.9312857", "0.9993779", "1", "0.9215877", "1", "1", "1", "1", "1", "1", "0.9998787", "1", "1", "1", "0.9999999", "1", "0.3223145", "0.9901338", "0.9520330", "0.9070189", "1", "1", "1", "1", "0.9848713", "1", "0.8168752", "1", "1", "0.7184402", "1", "0.9866779", "0.9999957", "0.6483352", "0.9917291", "1", "1", "1", "1", "1", "1", "1", "1", "0.8513884", "1", "1", "0.4995938", "0.9999706", "1", "0.9999999", "1", "0.9893014", "1", "1", "1", "0.9289412", "1", "0.99995192", "0.9999995", "1", "0.9999171", "1", "1", "1", "1", "0.8621987", "0.9999982", "0.8444916", "1", "1", "0.9907955", "1", "0.9995894", "0.8309161", "0.9991252", "1", "1", "1", "0.7201601", "0.9946313", "1", "0.9999965", "1", "0.8058269", "0.7067197", "0.5567686", "1", "0.5994809", "1", "1", "1", "1", "1", "0.6458963", "1", "1", "1", "0.9999705", "0.4884061", "0.6641290", "0.9969315", "0.9999546", "0.9999984", "0.6438147", "1", "0.8580797", "1", "1", "1", "1", "1", "1", "1", "0.9992031", "1", "0.4290772", "1", "1", "1", "1", "1", "1", "1", "1", "0.9999697", "1", "1", "0.9999944", "0.9745615", "1", "0.7791843", "0.9999999", "1", "1", "1", "0.9999887", "1", "1")


# Read in MCC (maximum clade credibility) tree in nexus format to get 95%_HPD
nexusMCC_tree <- read.beast("MCC_3genes_nexusTree")

# See list of 95% HPD
nexusMCC_tree@data$height_0.95_HPD

# Change the nexus tree format to ggtree format
gg.tree <- ggtree(nexusMCC_tree, branch.length = "branch.length")


#Usually we need to change our tip labels, as we might have been using a coded ID instead of the taxon name during the analysis or the programme we used may require tip labels to have underscores instead of spaces. This is where metadata comes into play: in your metadata file, the first column should be your tip labels, and then you can have any number of columns afterwards with other variables you may want to associate with your tree:

#Read in your metadata
metadata <- read.csv("metadata_Lauraceae.csv")
head(metadata)

#We can then add our metadata to our original ggtree object
gg.tree1 <- gg.tree %<+% metadata


#Add tip labels
gg.tree2 <- gg.tree1 +
  geom_tiplab(aes(label = tip.name), size = 3, fontface = "italic", offset = 2)
plot(gg.tree2)

gg.tree3 <- gg.tree2 
plot(gg.tree3)


#Make dataframe of subclade nodes
subclades.df <- data.frame(sc = unique(metadata$sub_clade),
                        node = NA)

#Find the most recent common ancestor for each clade (i.e., the node we want to highlight)
for (i in 1:length(subclades.df$sc)) {
  
  subclades.df$node[i] <- MRCA(nexusMCC_tree,
                            metadata$Tip[metadata$sub_clade == subclades.df$sc[i]])
  
}


# Named vector for colours
cols <- c("A" = "#EA3324", "B" = "#F1A23A", "C" = "yellow", "D" = "#D4FB79", "E" = "green", "F" = "#75FBFD", "G" = "#36B0F7", "H" = "#2E04F5", "I" = "#C82AF6")  

#Add range for the different species
gg.tree6 <- gg.tree3 +
  geom_tippoint(aes(color=Range_alphabet), show.legend = FALSE) +
  scale_color_manual(values = cols)
plot(gg.tree6)

# Add 95% HPD confidence interval
gg.tree7 <- gg.tree6 + geom_range('height_0.95_HPD', color='blue', size=1, 
                                  alpha=.5, center='height')
plot(gg.tree7)

---------------------------------------------------------------------------------
# Scaling to only see the ingroup
---------------------------------------------------------------------------------

#In additional to collapsing, we can also scale the clade, which may be helpful if you're trying to plot a really big tree. You must scale before you collapse, however
gg.tree8 <- scaleClade(gg.tree7,node = 149,
                       scale = 0.1) %>%
  scaleClade(node = 136,
             scale = 0.1) %>%
  scaleClade(node = 139,
             scale = 0.1) %>%
  scaleClade(node = 148,
             scale = 0.1) %>%
  collapse(node = 136,
           mode = "max",
           clade_name = "A") %>%
  collapse(node = 139,
           mode = "max",
           clade_name = "B") %>%
  collapse(node = 148,
           mode = "max",
           clade_name = "C") %>%
  collapse(node = 142,
           mode = "max",
           clade_name = "D")

revts(gg.tree8)


### Adding scalebar (indicating the different epochs)
gg.tree9 <- gg.tree8 + 
  coord_geo(xlim = c(35,-100), ylim = c(+12.5, Ntip(nexusMCC_tree)-12.5), neg = TRUE,dat = list("epochs", "periods"), abbrv = FALSE, size = list(3, 4), skip = c("Pleistocene", "Holocene", "Pliocene"), center_end_labels = TRUE) +
  scale_x_continuous(breaks = -rev(epochs$max_age), labels = rev(epochs$max_age)) +
  theme_tree2(plot.margin=margin())
revts(gg.tree9)


---------------------------------------------------------------------------------
# Scaling to only see the outgroup
---------------------------------------------------------------------------------
  #Add tip labels
  gg.tree2 <- gg.tree1 +
  geom_tiplab(aes(label = tip.name), size = 3, fontface = "italic", offset = 0.2)
plot(gg.tree2)

gg.tree3 <- gg.tree2 
plot(gg.tree3)


#Make dataframe of subclade nodes
subclades.df <- data.frame(sc = unique(metadata$sub_clade),
                           node = NA)

#Find the most recent common ancestor for each clade (i.e., the node we want to highlight)
for (i in 1:length(subclades.df$sc)) {
  
  subclades.df$node[i] <- MRCA(nexusMCC_tree,
                               metadata$Tip[metadata$sub_clade == subclades.df$sc[i]])
  
}

# Named vector for colours
cols <- c("A" = "#EA3324", "B" = "#F1A23A", "C" = "yellow", "D" = "#D4FB79", "E" = "green", "F" = "#75FBFD", "G" = "#36B0F7", "H" = "#2E04F5", "I" = "#C82AF6")  

#Add range for the different species
gg.tree6 <- gg.tree3 +
  geom_tippoint(aes(color=Range_alphabet), show.legend = FALSE) +
  scale_color_manual(values = cols)
plot(gg.tree6)

# Add 95% HPD confidence interval
gg.tree7 <- gg.tree6 + geom_range('height_0.95_HPD', color='blue', size=1, 
                                    alpha=.5, center='height')
plot(gg.tree7)
  #In additional to collapsing, we can also scale the clade, which may be helpful if you're trying to plot a really big tree. You must scale before you collapse, however
  gg.tree8 <- scaleClade(gg.tree7,node = 159,
                         scale = 0.001) %>%
  collapse(node = 159,
           mode = "max",
           clade_name = "D")

revts(gg.tree8)


### Adding scalebar (indicating the different epochs)
gg.tree9 <- gg.tree8 + 
  coord_geo(xlim = c(45,-130), ylim = c(+19, Ntip(nexusMCC_tree)-35), neg = TRUE,dat = list("epochs", "periods"), abbrv = FALSE, size = list(3, 4), skip = c("Pleistocene", "Holocene", "Pliocene"), center_end_labels = TRUE) +
  scale_x_continuous(breaks = -rev(epochs$max_age), labels = rev(epochs$max_age)) +
  theme_tree2(plot.margin=margin())
revts(gg.tree9)

---------------------------------------------------------------------------------
# Get entire tree
---------------------------------------------------------------------------------

#Add tip labels
gg.tree2 <- gg.tree1 +
  geom_tiplab(aes(label = tip.name), size = 2.5, fontface = "italic", offset = 2)
plot(gg.tree2)

gg.tree3 <- gg.tree2 
plot(gg.tree3)


#Make dataframe of subclade nodes
subclades.df <- data.frame(sc = unique(metadata$sub_clade),
                           node = NA)

#Find the most recent common ancestor for each clade (i.e., the node we want to highlight)
for (i in 1:length(subclades.df$sc)) {
  
  subclades.df$node[i] <- MRCA(nexusMCC_tree,
                               metadata$Tip[metadata$sub_clade == subclades.df$sc[i]])
  
}


# Named vector for colours
cols <- c("A" = "#EA3324", "B" = "#F1A23A", "C" = "yellow", "D" = "#D4FB79", "E" = "green", "F" = "#75FBFD", "G" = "#36B0F7", "H" = "#2E04F5", "I" = "#C82AF6")  

#Add range for the different species
gg.tree6 <- gg.tree3 +
  geom_tippoint(aes(color=Range_alphabet), show.legend = FALSE) +
  scale_color_manual(values = cols) + xlim(c(0, 148))
plot(gg.tree6)

---------------------------------------------------------------------------------
# To check node numbers
gg.tree3 +
  geom_text2(aes(subset = !isTip, label = node), hjust = -0.3)

